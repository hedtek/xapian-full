/* This file was generated automatically by the Snowball to ISO C++ compiler */

#include <limits.h>
#include "russian.h"

static const symbol s_pool[] = {
#define s_0_0 0
0xD0, 0xB2, 0xD1, 0x88, 0xD0, 0xB8, 0xD1, 0x81, 0xD1, 0x8C,
#define s_0_1 10
0xD1, 0x8B, 0xD0, 0xB2, 0xD1, 0x88, 0xD0, 0xB8, 0xD1, 0x81, 0xD1, 0x8C,
#define s_0_2 22
0xD0, 0xB8, 0xD0, 0xB2, 0xD1, 0x88, 0xD0, 0xB8, 0xD1, 0x81, 0xD1, 0x8C,
#define s_0_3 34
0xD0, 0xB2,
#define s_0_4 36
0xD1, 0x8B, 0xD0, 0xB2,
#define s_0_5 40
0xD0, 0xB8, 0xD0, 0xB2,
#define s_0_6 44
0xD0, 0xB2, 0xD1, 0x88, 0xD0, 0xB8,
#define s_0_7 50
0xD1, 0x8B, 0xD0, 0xB2, 0xD1, 0x88, 0xD0, 0xB8,
#define s_0_8 58
0xD0, 0xB8, 0xD0, 0xB2, 0xD1, 0x88, 0xD0, 0xB8,
#define s_1_0 66
0xD0, 0xB5, 0xD0, 0xBC, 0xD1, 0x83,
#define s_1_1 72
0xD0, 0xBE, 0xD0, 0xBC, 0xD1, 0x83,
#define s_1_2 78
0xD1, 0x8B, 0xD1, 0x85,
#define s_1_3 82
0xD0, 0xB8, 0xD1, 0x85,
#define s_1_4 86
0xD1, 0x83, 0xD1, 0x8E,
#define s_1_5 90
0xD1, 0x8E, 0xD1, 0x8E,
#define s_1_6 94
0xD0, 0xB5, 0xD1, 0x8E,
#define s_1_7 98
0xD0, 0xBE, 0xD1, 0x8E,
#define s_1_8 102
0xD1, 0x8F, 0xD1, 0x8F,
#define s_1_9 106
0xD0, 0xB0, 0xD1, 0x8F,
#define s_1_10 110
0xD1, 0x8B, 0xD0, 0xB5,
#define s_1_11 114
0xD0, 0xB5, 0xD0, 0xB5,
#define s_1_12 118
0xD0, 0xB8, 0xD0, 0xB5,
#define s_1_13 122
0xD0, 0xBE, 0xD0, 0xB5,
#define s_1_14 126
0xD1, 0x8B, 0xD0, 0xBC, 0xD0, 0xB8,
#define s_1_15 132
0xD0, 0xB8, 0xD0, 0xBC, 0xD0, 0xB8,
#define s_1_16 138
0xD1, 0x8B, 0xD0, 0xB9,
#define s_1_17 142
0xD0, 0xB5, 0xD0, 0xB9,
#define s_1_18 146
0xD0, 0xB8, 0xD0, 0xB9,
#define s_1_19 150
0xD0, 0xBE, 0xD0, 0xB9,
#define s_1_20 154
0xD1, 0x8B, 0xD0, 0xBC,
#define s_1_21 158
0xD0, 0xB5, 0xD0, 0xBC,
#define s_1_22 162
0xD0, 0xB8, 0xD0, 0xBC,
#define s_1_23 166
0xD0, 0xBE, 0xD0, 0xBC,
#define s_1_24 170
0xD0, 0xB5, 0xD0, 0xB3, 0xD0, 0xBE,
#define s_1_25 176
0xD0, 0xBE, 0xD0, 0xB3, 0xD0, 0xBE,
#define s_2_0 182
0xD0, 0xB2, 0xD1, 0x88,
#define s_2_1 186
0xD1, 0x8B, 0xD0, 0xB2, 0xD1, 0x88,
#define s_2_2 192
0xD0, 0xB8, 0xD0, 0xB2, 0xD1, 0x88,
#define s_2_3 198
0xD1, 0x89,
#define s_2_4 200
0xD1, 0x8E, 0xD1, 0x89,
#define s_2_5 204
0xD1, 0x83, 0xD1, 0x8E, 0xD1, 0x89,
#define s_2_6 210
0xD0, 0xB5, 0xD0, 0xBC,
#define s_2_7 214
0xD0, 0xBD, 0xD0, 0xBD,
#define s_3_0 218
0xD1, 0x81, 0xD1, 0x8C,
#define s_3_1 222
0xD1, 0x81, 0xD1, 0x8F,
#define s_4_0 226
0xD1, 0x8B, 0xD1, 0x82,
#define s_4_1 230
0xD1, 0x8E, 0xD1, 0x82,
#define s_4_2 234
0xD1, 0x83, 0xD1, 0x8E, 0xD1, 0x82,
#define s_4_3 240
0xD1, 0x8F, 0xD1, 0x82,
#define s_4_4 244
0xD0, 0xB5, 0xD1, 0x82,
#define s_4_5 248
0xD1, 0x83, 0xD0, 0xB5, 0xD1, 0x82,
#define s_4_6 254
0xD0, 0xB8, 0xD1, 0x82,
#define s_4_7 258
0xD0, 0xBD, 0xD1, 0x8B,
#define s_4_8 262
0xD0, 0xB5, 0xD0, 0xBD, 0xD1, 0x8B,
#define s_4_9 268
0xD1, 0x82, 0xD1, 0x8C,
#define s_4_10 272
0xD1, 0x8B, 0xD1, 0x82, 0xD1, 0x8C,
#define s_4_11 278
0xD0, 0xB8, 0xD1, 0x82, 0xD1, 0x8C,
#define s_4_12 284
0xD0, 0xB5, 0xD1, 0x88, 0xD1, 0x8C,
#define s_4_13 290
0xD0, 0xB8, 0xD1, 0x88, 0xD1, 0x8C,
#define s_4_14 296
0xD1, 0x8E,
#define s_4_15 298
0xD1, 0x83, 0xD1, 0x8E,
#define s_4_16 302
0xD0, 0xBB, 0xD0, 0xB0,
#define s_4_17 306
0xD1, 0x8B, 0xD0, 0xBB, 0xD0, 0xB0,
#define s_4_18 312
0xD0, 0xB8, 0xD0, 0xBB, 0xD0, 0xB0,
#define s_4_19 318
0xD0, 0xBD, 0xD0, 0xB0,
#define s_4_20 322
0xD0, 0xB5, 0xD0, 0xBD, 0xD0, 0xB0,
#define s_4_21 328
0xD0, 0xB5, 0xD1, 0x82, 0xD0, 0xB5,
#define s_4_22 334
0xD0, 0xB8, 0xD1, 0x82, 0xD0, 0xB5,
#define s_4_23 340
0xD0, 0xB9, 0xD1, 0x82, 0xD0, 0xB5,
#define s_4_24 346
0xD1, 0x83, 0xD0, 0xB9, 0xD1, 0x82, 0xD0, 0xB5,
#define s_4_25 354
0xD0, 0xB5, 0xD0, 0xB9, 0xD1, 0x82, 0xD0, 0xB5,
#define s_4_26 362
0xD0, 0xBB, 0xD0, 0xB8,
#define s_4_27 366
0xD1, 0x8B, 0xD0, 0xBB, 0xD0, 0xB8,
#define s_4_28 372
0xD0, 0xB8, 0xD0, 0xBB, 0xD0, 0xB8,
#define s_4_29 378
0xD0, 0xB9,
#define s_4_30 380
0xD1, 0x83, 0xD0, 0xB9,
#define s_4_31 384
0xD0, 0xB5, 0xD0, 0xB9,
#define s_4_32 388
0xD0, 0xBB,
#define s_4_33 390
0xD1, 0x8B, 0xD0, 0xBB,
#define s_4_34 394
0xD0, 0xB8, 0xD0, 0xBB,
#define s_4_35 398
0xD1, 0x8B, 0xD0, 0xBC,
#define s_4_36 402
0xD0, 0xB5, 0xD0, 0xBC,
#define s_4_37 406
0xD0, 0xB8, 0xD0, 0xBC,
#define s_4_38 410
0xD0, 0xBD,
#define s_4_39 412
0xD0, 0xB5, 0xD0, 0xBD,
#define s_4_40 416
0xD0, 0xBB, 0xD0, 0xBE,
#define s_4_41 420
0xD1, 0x8B, 0xD0, 0xBB, 0xD0, 0xBE,
#define s_4_42 426
0xD0, 0xB8, 0xD0, 0xBB, 0xD0, 0xBE,
#define s_4_43 432
0xD0, 0xBD, 0xD0, 0xBE,
#define s_4_44 436
0xD0, 0xB5, 0xD0, 0xBD, 0xD0, 0xBE,
#define s_4_45 442
0xD0, 0xBD, 0xD0, 0xBD, 0xD0, 0xBE,
#define s_5_0 448
0xD1, 0x83,
#define s_5_1 450
0xD1, 0x8F, 0xD1, 0x85,
#define s_5_2 454
0xD0, 0xB8, 0xD1, 0x8F, 0xD1, 0x85,
#define s_5_3 460
0xD0, 0xB0, 0xD1, 0x85,
#define s_5_4 464
0xD1, 0x8B,
#define s_5_5 466
0xD1, 0x8C,
#define s_5_6 468
0xD1, 0x8E,
#define s_5_7 470
0xD1, 0x8C, 0xD1, 0x8E,
#define s_5_8 474
0xD0, 0xB8, 0xD1, 0x8E,
#define s_5_9 478
0xD1, 0x8F,
#define s_5_10 480
0xD1, 0x8C, 0xD1, 0x8F,
#define s_5_11 484
0xD0, 0xB8, 0xD1, 0x8F,
#define s_5_12 488
0xD0, 0xB0,
#define s_5_13 490
0xD0, 0xB5, 0xD0, 0xB2,
#define s_5_14 494
0xD0, 0xBE, 0xD0, 0xB2,
#define s_5_15 498
0xD0, 0xB5,
#define s_5_16 500
0xD1, 0x8C, 0xD0, 0xB5,
#define s_5_17 504
0xD0, 0xB8, 0xD0, 0xB5,
#define s_5_18 508
0xD0, 0xB8,
#define s_5_19 510
0xD0, 0xB5, 0xD0, 0xB8,
#define s_5_20 514
0xD0, 0xB8, 0xD0, 0xB8,
#define s_5_21 518
0xD1, 0x8F, 0xD0, 0xBC, 0xD0, 0xB8,
#define s_5_22 524
0xD0, 0xB8, 0xD1, 0x8F, 0xD0, 0xBC, 0xD0, 0xB8,
#define s_5_23 532
0xD0, 0xB0, 0xD0, 0xBC, 0xD0, 0xB8,
#define s_5_24 538
0xD0, 0xB9,
#define s_5_25 540
0xD0, 0xB5, 0xD0, 0xB9,
#define s_5_26 544
0xD0, 0xB8, 0xD0, 0xB5, 0xD0, 0xB9,
#define s_5_27 550
0xD0, 0xB8, 0xD0, 0xB9,
#define s_5_28 554
0xD0, 0xBE, 0xD0, 0xB9,
#define s_5_29 558
0xD1, 0x8F, 0xD0, 0xBC,
#define s_5_30 562
0xD0, 0xB8, 0xD1, 0x8F, 0xD0, 0xBC,
#define s_5_31 568
0xD0, 0xB0, 0xD0, 0xBC,
#define s_5_32 572
0xD0, 0xB5, 0xD0, 0xBC,
#define s_5_33 576
0xD0, 0xB8, 0xD0, 0xB5, 0xD0, 0xBC,
#define s_5_34 582
0xD0, 0xBE, 0xD0, 0xBC,
#define s_5_35 586
0xD0, 0xBE,
#define s_6_0 588
0xD0, 0xBE, 0xD1, 0x81, 0xD1, 0x82,
#define s_6_1 594
0xD0, 0xBE, 0xD1, 0x81, 0xD1, 0x82, 0xD1, 0x8C,
#define s_7_0 602
0xD0, 0xB5, 0xD0, 0xB9, 0xD1, 0x88,
#define s_7_1 608
0xD1, 0x8C,
#define s_7_2 610
0xD0, 0xB5, 0xD0, 0xB9, 0xD1, 0x88, 0xD0, 0xB5,
#define s_7_3 618
0xD0, 0xBD,
};


static const struct among a_0[9] =
{
/*  0 */ { 10, s_0_0, -1, 1},
/*  1 */ { 12, s_0_1, 0, 2},
/*  2 */ { 12, s_0_2, 0, 2},
/*  3 */ { 2, s_0_3, -1, 1},
/*  4 */ { 4, s_0_4, 3, 2},
/*  5 */ { 4, s_0_5, 3, 2},
/*  6 */ { 6, s_0_6, -1, 1},
/*  7 */ { 8, s_0_7, 6, 2},
/*  8 */ { 8, s_0_8, 6, 2}
};


static const struct among a_1[26] =
{
/*  0 */ { 6, s_1_0, -1, 1},
/*  1 */ { 6, s_1_1, -1, 1},
/*  2 */ { 4, s_1_2, -1, 1},
/*  3 */ { 4, s_1_3, -1, 1},
/*  4 */ { 4, s_1_4, -1, 1},
/*  5 */ { 4, s_1_5, -1, 1},
/*  6 */ { 4, s_1_6, -1, 1},
/*  7 */ { 4, s_1_7, -1, 1},
/*  8 */ { 4, s_1_8, -1, 1},
/*  9 */ { 4, s_1_9, -1, 1},
/* 10 */ { 4, s_1_10, -1, 1},
/* 11 */ { 4, s_1_11, -1, 1},
/* 12 */ { 4, s_1_12, -1, 1},
/* 13 */ { 4, s_1_13, -1, 1},
/* 14 */ { 6, s_1_14, -1, 1},
/* 15 */ { 6, s_1_15, -1, 1},
/* 16 */ { 4, s_1_16, -1, 1},
/* 17 */ { 4, s_1_17, -1, 1},
/* 18 */ { 4, s_1_18, -1, 1},
/* 19 */ { 4, s_1_19, -1, 1},
/* 20 */ { 4, s_1_20, -1, 1},
/* 21 */ { 4, s_1_21, -1, 1},
/* 22 */ { 4, s_1_22, -1, 1},
/* 23 */ { 4, s_1_23, -1, 1},
/* 24 */ { 6, s_1_24, -1, 1},
/* 25 */ { 6, s_1_25, -1, 1}
};


static const struct among a_2[8] =
{
/*  0 */ { 4, s_2_0, -1, 1},
/*  1 */ { 6, s_2_1, 0, 2},
/*  2 */ { 6, s_2_2, 0, 2},
/*  3 */ { 2, s_2_3, -1, 1},
/*  4 */ { 4, s_2_4, 3, 1},
/*  5 */ { 6, s_2_5, 4, 2},
/*  6 */ { 4, s_2_6, -1, 1},
/*  7 */ { 4, s_2_7, -1, 1}
};


static const struct among a_3[2] =
{
/*  0 */ { 4, s_3_0, -1, 1},
/*  1 */ { 4, s_3_1, -1, 1}
};


static const struct among a_4[46] =
{
/*  0 */ { 4, s_4_0, -1, 2},
/*  1 */ { 4, s_4_1, -1, 1},
/*  2 */ { 6, s_4_2, 1, 2},
/*  3 */ { 4, s_4_3, -1, 2},
/*  4 */ { 4, s_4_4, -1, 1},
/*  5 */ { 6, s_4_5, 4, 2},
/*  6 */ { 4, s_4_6, -1, 2},
/*  7 */ { 4, s_4_7, -1, 1},
/*  8 */ { 6, s_4_8, 7, 2},
/*  9 */ { 4, s_4_9, -1, 1},
/* 10 */ { 6, s_4_10, 9, 2},
/* 11 */ { 6, s_4_11, 9, 2},
/* 12 */ { 6, s_4_12, -1, 1},
/* 13 */ { 6, s_4_13, -1, 2},
/* 14 */ { 2, s_4_14, -1, 2},
/* 15 */ { 4, s_4_15, 14, 2},
/* 16 */ { 4, s_4_16, -1, 1},
/* 17 */ { 6, s_4_17, 16, 2},
/* 18 */ { 6, s_4_18, 16, 2},
/* 19 */ { 4, s_4_19, -1, 1},
/* 20 */ { 6, s_4_20, 19, 2},
/* 21 */ { 6, s_4_21, -1, 1},
/* 22 */ { 6, s_4_22, -1, 2},
/* 23 */ { 6, s_4_23, -1, 1},
/* 24 */ { 8, s_4_24, 23, 2},
/* 25 */ { 8, s_4_25, 23, 2},
/* 26 */ { 4, s_4_26, -1, 1},
/* 27 */ { 6, s_4_27, 26, 2},
/* 28 */ { 6, s_4_28, 26, 2},
/* 29 */ { 2, s_4_29, -1, 1},
/* 30 */ { 4, s_4_30, 29, 2},
/* 31 */ { 4, s_4_31, 29, 2},
/* 32 */ { 2, s_4_32, -1, 1},
/* 33 */ { 4, s_4_33, 32, 2},
/* 34 */ { 4, s_4_34, 32, 2},
/* 35 */ { 4, s_4_35, -1, 2},
/* 36 */ { 4, s_4_36, -1, 1},
/* 37 */ { 4, s_4_37, -1, 2},
/* 38 */ { 2, s_4_38, -1, 1},
/* 39 */ { 4, s_4_39, 38, 2},
/* 40 */ { 4, s_4_40, -1, 1},
/* 41 */ { 6, s_4_41, 40, 2},
/* 42 */ { 6, s_4_42, 40, 2},
/* 43 */ { 4, s_4_43, -1, 1},
/* 44 */ { 6, s_4_44, 43, 2},
/* 45 */ { 6, s_4_45, 43, 1}
};


static const struct among a_5[36] =
{
/*  0 */ { 2, s_5_0, -1, 1},
/*  1 */ { 4, s_5_1, -1, 1},
/*  2 */ { 6, s_5_2, 1, 1},
/*  3 */ { 4, s_5_3, -1, 1},
/*  4 */ { 2, s_5_4, -1, 1},
/*  5 */ { 2, s_5_5, -1, 1},
/*  6 */ { 2, s_5_6, -1, 1},
/*  7 */ { 4, s_5_7, 6, 1},
/*  8 */ { 4, s_5_8, 6, 1},
/*  9 */ { 2, s_5_9, -1, 1},
/* 10 */ { 4, s_5_10, 9, 1},
/* 11 */ { 4, s_5_11, 9, 1},
/* 12 */ { 2, s_5_12, -1, 1},
/* 13 */ { 4, s_5_13, -1, 1},
/* 14 */ { 4, s_5_14, -1, 1},
/* 15 */ { 2, s_5_15, -1, 1},
/* 16 */ { 4, s_5_16, 15, 1},
/* 17 */ { 4, s_5_17, 15, 1},
/* 18 */ { 2, s_5_18, -1, 1},
/* 19 */ { 4, s_5_19, 18, 1},
/* 20 */ { 4, s_5_20, 18, 1},
/* 21 */ { 6, s_5_21, 18, 1},
/* 22 */ { 8, s_5_22, 21, 1},
/* 23 */ { 6, s_5_23, 18, 1},
/* 24 */ { 2, s_5_24, -1, 1},
/* 25 */ { 4, s_5_25, 24, 1},
/* 26 */ { 6, s_5_26, 25, 1},
/* 27 */ { 4, s_5_27, 24, 1},
/* 28 */ { 4, s_5_28, 24, 1},
/* 29 */ { 4, s_5_29, -1, 1},
/* 30 */ { 6, s_5_30, 29, 1},
/* 31 */ { 4, s_5_31, -1, 1},
/* 32 */ { 4, s_5_32, -1, 1},
/* 33 */ { 6, s_5_33, 32, 1},
/* 34 */ { 4, s_5_34, -1, 1},
/* 35 */ { 2, s_5_35, -1, 1}
};


static const struct among a_6[2] =
{
/*  0 */ { 6, s_6_0, -1, 1},
/*  1 */ { 8, s_6_1, -1, 1}
};


static const struct among a_7[4] =
{
/*  0 */ { 6, s_7_0, -1, 1},
/*  1 */ { 2, s_7_1, -1, 3},
/*  2 */ { 8, s_7_2, -1, 1},
/*  3 */ { 2, s_7_3, -1, 2}
};

static const unsigned char g_v[] = { 33, 65, 8, 232 };

static const symbol s_0[] = { 0xD0, 0xB0 };
static const symbol s_1[] = { 0xD1, 0x8F };
static const symbol s_2[] = { 0xD0, 0xB0 };
static const symbol s_3[] = { 0xD1, 0x8F };
static const symbol s_4[] = { 0xD0, 0xB0 };
static const symbol s_5[] = { 0xD1, 0x8F };
static const symbol s_6[] = { 0xD0, 0xBD };
static const symbol s_7[] = { 0xD0, 0xBD };
static const symbol s_8[] = { 0xD0, 0xBD };
static const symbol s_9[] = { 0xD0, 0xB8 };

int Xapian::InternalStemRussian::r_mark_regions() { /* forwardmode */
    I_pV = l; /* pV = <integer expression>, line 59 */
    I_p2 = l; /* p2 = <integer expression>, line 60 */
    {   int c1 = c; /* do, line 61 */
        {   int ret = out_grouping_U(g_v, 1072, 1103, 1); /* gopast */ /* grouping v, line 62 */
            if (ret < 0) goto lab0;
            c += ret;
        }
        I_pV = c; /* setmark pV, line 62 */
        {   int ret = in_grouping_U(g_v, 1072, 1103, 1); /* gopast */ /* non v, line 62 */
            if (ret < 0) goto lab0;
            c += ret;
        }
        {   int ret = out_grouping_U(g_v, 1072, 1103, 1); /* gopast */ /* grouping v, line 63 */
            if (ret < 0) goto lab0;
            c += ret;
        }
        {   int ret = in_grouping_U(g_v, 1072, 1103, 1); /* gopast */ /* non v, line 63 */
            if (ret < 0) goto lab0;
            c += ret;
        }
        I_p2 = c; /* setmark p2, line 63 */
    lab0:
        c = c1;
    }
    return 1;
}

int Xapian::InternalStemRussian::r_R2() { /* backwardmode */
    if (!(I_p2 <= c)) return 0; /* p2 <= <integer expression>, line 69 */
    return 1;
}

int Xapian::InternalStemRussian::r_perfective_gerund() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 72 */
    among_var = find_among_b(s_pool, a_0, 9, 0, 0); /* substring, line 72 */
    if (!(among_var)) return 0;
    bra = c; /* ], line 72 */
    switch(among_var) { /* among, line 72 */
        case 0: return 0;
        case 1:
            {   int m1 = l - c; (void)m1; /* or, line 76 */
                if (!(eq_s_b(2, s_0))) goto lab1; /* literal, line 76 */
                goto lab0;
            lab1:
                c = l - m1;
                if (!(eq_s_b(2, s_1))) return 0; /* literal, line 76 */
            }
        lab0:
            if (slice_del() == -1) return -1; /* delete, line 76 */
            break;
        case 2:
            if (slice_del() == -1) return -1; /* delete, line 83 */
            break;
    }
    return 1;
}

int Xapian::InternalStemRussian::r_adjective() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 88 */
    among_var = find_among_b(s_pool, a_1, 26, 0, 0); /* substring, line 88 */
    if (!(among_var)) return 0;
    bra = c; /* ], line 88 */
    switch(among_var) { /* among, line 88 */
        case 0: return 0;
        case 1:
            if (slice_del() == -1) return -1; /* delete, line 97 */
            break;
    }
    return 1;
}

int Xapian::InternalStemRussian::r_adjectival() { /* backwardmode */
    int among_var;
    {   int ret = r_adjective(); /* call adjective, line 102 */
        if (ret <= 0) return ret;
    }
    {   int m1 = l - c; (void)m1; /* try, line 109 */
        ket = c; /* [, line 110 */
        among_var = find_among_b(s_pool, a_2, 8, 0, 0); /* substring, line 110 */
        if (!(among_var)) { c = l - m1; goto lab0; }
        bra = c; /* ], line 110 */
        switch(among_var) { /* among, line 110 */
            case 0: { c = l - m1; goto lab0; }
            case 1:
                {   int m2 = l - c; (void)m2; /* or, line 115 */
                    if (!(eq_s_b(2, s_2))) goto lab2; /* literal, line 115 */
                    goto lab1;
                lab2:
                    c = l - m2;
                    if (!(eq_s_b(2, s_3))) { c = l - m1; goto lab0; } /* literal, line 115 */
                }
            lab1:
                if (slice_del() == -1) return -1; /* delete, line 115 */
                break;
            case 2:
                if (slice_del() == -1) return -1; /* delete, line 122 */
                break;
        }
    lab0:
        ;
    }
    return 1;
}

int Xapian::InternalStemRussian::r_reflexive() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 129 */
    if (c - 3 <= lb || (p[c - 1] != 140 && p[c - 1] != 143)) return 0; /* substring, line 129 */
    among_var = find_among_b(s_pool, a_3, 2, 0, 0);
    if (!(among_var)) return 0;
    bra = c; /* ], line 129 */
    switch(among_var) { /* among, line 129 */
        case 0: return 0;
        case 1:
            if (slice_del() == -1) return -1; /* delete, line 132 */
            break;
    }
    return 1;
}

int Xapian::InternalStemRussian::r_verb() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 137 */
    among_var = find_among_b(s_pool, a_4, 46, 0, 0); /* substring, line 137 */
    if (!(among_var)) return 0;
    bra = c; /* ], line 137 */
    switch(among_var) { /* among, line 137 */
        case 0: return 0;
        case 1:
            {   int m1 = l - c; (void)m1; /* or, line 143 */
                if (!(eq_s_b(2, s_4))) goto lab1; /* literal, line 143 */
                goto lab0;
            lab1:
                c = l - m1;
                if (!(eq_s_b(2, s_5))) return 0; /* literal, line 143 */
            }
        lab0:
            if (slice_del() == -1) return -1; /* delete, line 143 */
            break;
        case 2:
            if (slice_del() == -1) return -1; /* delete, line 151 */
            break;
    }
    return 1;
}

int Xapian::InternalStemRussian::r_noun() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 160 */
    among_var = find_among_b(s_pool, a_5, 36, 0, 0); /* substring, line 160 */
    if (!(among_var)) return 0;
    bra = c; /* ], line 160 */
    switch(among_var) { /* among, line 160 */
        case 0: return 0;
        case 1:
            if (slice_del() == -1) return -1; /* delete, line 167 */
            break;
    }
    return 1;
}

int Xapian::InternalStemRussian::r_derivational() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 176 */
    if (c - 5 <= lb || (p[c - 1] != 130 && p[c - 1] != 140)) return 0; /* substring, line 176 */
    among_var = find_among_b(s_pool, a_6, 2, 0, 0);
    if (!(among_var)) return 0;
    bra = c; /* ], line 176 */
    {   int ret = r_R2(); /* call R2, line 176 */
        if (ret <= 0) return ret;
    }
    switch(among_var) { /* among, line 176 */
        case 0: return 0;
        case 1:
            if (slice_del() == -1) return -1; /* delete, line 179 */
            break;
    }
    return 1;
}

int Xapian::InternalStemRussian::r_tidy_up() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 184 */
    among_var = find_among_b(s_pool, a_7, 4, 0, 0); /* substring, line 184 */
    if (!(among_var)) return 0;
    bra = c; /* ], line 184 */
    switch(among_var) { /* among, line 184 */
        case 0: return 0;
        case 1:
            if (slice_del() == -1) return -1; /* delete, line 188 */
            ket = c; /* [, line 189 */
            if (!(eq_s_b(2, s_6))) return 0; /* literal, line 189 */
            bra = c; /* ], line 189 */
            if (!(eq_s_b(2, s_7))) return 0; /* literal, line 189 */
            if (slice_del() == -1) return -1; /* delete, line 189 */
            break;
        case 2:
            if (!(eq_s_b(2, s_8))) return 0; /* literal, line 192 */
            if (slice_del() == -1) return -1; /* delete, line 192 */
            break;
        case 3:
            if (slice_del() == -1) return -1; /* delete, line 194 */
            break;
    }
    return 1;
}

int Xapian::InternalStemRussian::stem() { /* forwardmode */
    {   int c1 = c; /* do, line 201 */
        {   int ret = r_mark_regions(); /* call mark_regions, line 201 */
            if (ret == 0) goto lab0;
            if (ret < 0) return ret;
        }
    lab0:
        c = c1;
    }
    lb = c; c = l; /* backwards, line 202 */

    {   int m2 = l - c; (void)m2; /* setlimit, line 202 */
        int mlimit2;
        if (c < I_pV) return 0;
        c = I_pV; /* tomark, line 202 */
        mlimit2 = lb; lb = c;
        c = l - m2;
        {   int m3 = l - c; (void)m3; /* do, line 203 */
            {   int m4 = l - c; (void)m4; /* or, line 204 */
                {   int ret = r_perfective_gerund(); /* call perfective_gerund, line 204 */
                    if (ret == 0) goto lab3;
                    if (ret < 0) return ret;
                }
                goto lab2;
            lab3:
                c = l - m4;
                {   int m5 = l - c; (void)m5; /* try, line 205 */
                    {   int ret = r_reflexive(); /* call reflexive, line 205 */
                        if (ret == 0) { c = l - m5; goto lab4; }
                        if (ret < 0) return ret;
                    }
                lab4:
                    ;
                }
                {   int m6 = l - c; (void)m6; /* or, line 206 */
                    {   int ret = r_adjectival(); /* call adjectival, line 206 */
                        if (ret == 0) goto lab6;
                        if (ret < 0) return ret;
                    }
                    goto lab5;
                lab6:
                    c = l - m6;
                    {   int ret = r_verb(); /* call verb, line 206 */
                        if (ret == 0) goto lab7;
                        if (ret < 0) return ret;
                    }
                    goto lab5;
                lab7:
                    c = l - m6;
                    {   int ret = r_noun(); /* call noun, line 206 */
                        if (ret == 0) goto lab1;
                        if (ret < 0) return ret;
                    }
                }
            lab5:
                ;
            }
        lab2:
        lab1:
            c = l - m3;
        }
        {   int m7 = l - c; (void)m7; /* try, line 209 */
            ket = c; /* [, line 209 */
            if (!(eq_s_b(2, s_9))) { c = l - m7; goto lab8; } /* literal, line 209 */
            bra = c; /* ], line 209 */
            if (slice_del() == -1) return -1; /* delete, line 209 */
        lab8:
            ;
        }
        {   int m8 = l - c; (void)m8; /* do, line 212 */
            {   int ret = r_derivational(); /* call derivational, line 212 */
                if (ret == 0) goto lab9;
                if (ret < 0) return ret;
            }
        lab9:
            c = l - m8;
        }
        {   int m9 = l - c; (void)m9; /* do, line 213 */
            {   int ret = r_tidy_up(); /* call tidy_up, line 213 */
                if (ret == 0) goto lab10;
                if (ret < 0) return ret;
            }
        lab10:
            c = l - m9;
        }
        lb = mlimit2;
    }
    c = lb;
    return 1;
}

Xapian::InternalStemRussian::InternalStemRussian()
    : I_p2(0), I_pV(0)
{
}

Xapian::InternalStemRussian::~InternalStemRussian()
{
}

const char *
Xapian::InternalStemRussian::get_description() const
{
    return "russian";
}
